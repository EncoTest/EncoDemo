﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace EncoTestProj.Models
{
    public class EncoRepository:IEncoRpository
    {
        private EncoTestDBEntities _dbContext;
        public EncoRepository(EncoTestDBEntities EncoContext)
        {
            this._dbContext = EncoContext;
        }
        public List<EncoNote> GetAllEncoNotes()
        {
            return _dbContext.EncoNotes.ToList();
        }
        public EncoNote GetEncoNotesById(int id)
        {
            return _dbContext.EncoNotes.Find(id);
        }
        public void Insert(EncoNote book)
        {
            _dbContext.EncoNotes.Add(book);
        }
        public void Delete(int bookID)
        {
            EncoNote book = _dbContext.EncoNotes.Find(bookID);
            _dbContext.EncoNotes.Remove(book);
        }
        public void Update(EncoNote book)
        {
            _dbContext.Entry(book).State = EntityState.Modified;
        }
        public void Save()
        {
            _dbContext.SaveChanges();
        }
        private bool disposed = false;
        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    _dbContext.Dispose();
                }
            }
            this.disposed = true;
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }        
    }
}