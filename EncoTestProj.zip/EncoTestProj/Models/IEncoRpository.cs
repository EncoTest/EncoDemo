﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EncoTestProj.Models
{
    public interface IEncoRpository
    {
        EncoNote GetEncoNotesById(int id);
        List<EncoNote> GetAllEncoNotes();
        void Insert(EncoNote note);
        void Delete(int noteID);
        void Update(EncoNote note);
        void Save();

    }
}
