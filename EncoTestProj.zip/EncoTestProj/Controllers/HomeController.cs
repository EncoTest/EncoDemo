﻿using EncoTestProj.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace EncoTestProj.Controllers
{
    public class HomeController : Controller
    {
        private readonly EncoTestDBEntities _dbContext = new EncoTestDBEntities();
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(EncoTestProj.Models.EncoUser user)
        {
            if (ModelState.IsValid)
            {
                var IsValidUser = _dbContext.EncoUsers.FirstOrDefault(u => u.UserName == user.UserName && u.Password == user.Password);

                if (IsValidUser != null)
                {
                    FormsAuthentication.SetAuthCookie(user.UserName, false);
                    return RedirectToAction("Index", "NoteList");
                }
                else
                {
                    ModelState.AddModelError("InvalidUserNameOrPassword", "Invalid Username or Password");                    
                }                
            }
            return View("Error");
        }
    }
}