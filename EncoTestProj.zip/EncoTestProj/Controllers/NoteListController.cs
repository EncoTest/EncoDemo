﻿using EncoTestProj.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace EncoTestProj.Controllers
{
    [Authorize]
    public class NoteListController : Controller
    {
        private IEncoRpository _encoRepository;
        public NoteListController()
        {
            this._encoRepository = new EncoRepository(new EncoTestDBEntities());
        }
        public ActionResult Index()
        {
            var notes = from EncoNote in _encoRepository.GetAllEncoNotes()
                        select EncoNote;
            return View(notes);
        }
        public ActionResult Create()
        {
            //var notes = from EncoNote in _encoRepository.GetAllEncoNotes()
            //            select EncoNote;

            return View(new EncoNote());            
        }
        [HttpPost]
        public ActionResult Create(EncoNote note)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _encoRepository.Insert(note);
                    _encoRepository.Save();
                    return RedirectToAction("Index");
                }
            }
            catch (System.Data.DataException)
            {
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }
            return View(note);
        }
        public ActionResult Edit(int id)
        {
            EncoNote encoNote = _encoRepository.GetEncoNotesById(id);
            return View(encoNote);
        }
        [HttpPost]
        public ActionResult Edit(EncoNote encoNote)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _encoRepository.Update(encoNote);
                    _encoRepository.Save();
                    return RedirectToAction("Index");
                }
            }
            catch (DataException)
            {
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }
            return View(encoNote);
        }
        public ActionResult Delete(int id, bool? saveChangesError)
        {
            if (saveChangesError.GetValueOrDefault())
            {
                ViewBag.ErrorMessage = "Unable to save changes. Try again, and if the problem persists see your system administrator.";
            }
            EncoNote encoNote = _encoRepository.GetEncoNotesById(id);
            return View(encoNote);
        }
        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            try
            {
                EncoNote encoNote = _encoRepository.GetEncoNotesById(id);
                _encoRepository.Delete(id);
                _encoRepository.Save();
            }
            catch (DataException)
            {
                return RedirectToAction("Delete",
                   new System.Web.Routing.RouteValueDictionary {
        { "id", id },
        { "saveChangesError", true } });
            }
            return RedirectToAction("Index");
        }
    }
}